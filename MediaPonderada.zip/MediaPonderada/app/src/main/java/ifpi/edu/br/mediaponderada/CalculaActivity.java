package ifpi.edu.br.mediaponderada;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class CalculaActivity extends AppCompatActivity {

    EditText editPeso1,editPeso2;
    double nota1,nota2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calcula);

        editPeso1 = findViewById(R.id.peso1);
        editPeso2 = findViewById(R.id.peso2);
        nota1 = getIntent().getDoubleExtra("nota1",-1);
        nota2 = getIntent().getDoubleExtra("nota2",-1);

    }

    public void calculo(View view) {
        Double peso1 = Double.valueOf(editPeso1.getText().toString());
        Double peso2 = Double.valueOf(editPeso2.getText().toString());
        final double media= ((nota1 * peso1) + (nota2 * peso2)) / (peso1 + peso2);


        startActivity(new Intent(this, NotasActivity.class).putExtra("media", media));



    }

    public void cancelarCalculo(View view) {
        startActivity(new Intent(this,NotasActivity.class));
        finish();
    }
}

