package ifpi.edu.br.mediaponderada;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editNome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        editNome = findViewById(R.id.nome);
    }

    public void confirmar(View view) {
        SharedPreferences preferences = getSharedPreferences("preferencias", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();

        if(!editNome.getText().toString().trim().isEmpty()) {

            editor.putString("nomeDoUsuario", editNome.getText().toString());

            editor.apply();

            startActivity(new Intent(this, NotasActivity.class));
            finish();
        }

        else
            Toast.makeText(this, "Nome não preenchido", Toast.LENGTH_SHORT).show();

    }
}
