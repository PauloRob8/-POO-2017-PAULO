package ifpi.edu.br.mediaponderada;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class NotasActivity extends AppCompatActivity {


    EditText editNota1,editNota2;
    private double media;
    private String nome;
    TextView resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notas);

        SharedPreferences preferences = getSharedPreferences("preferencias",MODE_PRIVATE);

        editNota1 = findViewById(R.id.nota1);
        editNota2 = findViewById(R.id.nota2);
        resultado = findViewById(R.id.resultado);
        media = getIntent().getDoubleExtra("media",-1);
        nome = preferences.getString("nomeDoUsuario","");

    }

    @Override
    protected void onResume() {
        super.onResume();

        if (media != -1){
            if (media >= 7){
                resultado.setText("Parabens "+nome+", você foi aprovado com media"+media);
            }else if(media > 4 && media < 7){
                final double notaRequerida = 12 - media;
                resultado.setText("Cuidado "+nome+", você ficou de prova final. sua media foi "+media+" e você precisa obter "+notaRequerida);
            }else{
                resultado.setText("Sinto muito "+nome+", você foi reprovado. Sua media foi "+media);
            }

        }
    }


    public void calcularMedia(View view) {
        startActivity(new Intent(this, CalculaActivity.class)
                .putExtra("nota1", Double.valueOf(editNota1.getText().toString()))
                .putExtra("nota2", Double.valueOf(editNota1.getText().toString())));
    }

}
