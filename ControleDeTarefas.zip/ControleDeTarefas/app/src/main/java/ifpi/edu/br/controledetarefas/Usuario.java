package ifpi.edu.br.controledetarefas;

import io.objectbox.annotation.Entity;
import io.objectbox.annotation.Id;


@Entity
public class Usuario {

    @Id
    private long id;
    private String chave;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getChave() {
        return chave;
    }

    public void setChave(String chave) {
        this.chave = chave;
    }

}
