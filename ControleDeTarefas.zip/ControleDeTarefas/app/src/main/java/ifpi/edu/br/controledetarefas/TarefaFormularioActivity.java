package ifpi.edu.br.controledetarefas;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class TarefaFormularioActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarefa_formulario);
    }
}
