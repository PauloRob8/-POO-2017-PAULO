package ifpi.edu.br.controledetarefas;

/**
 * Created by aluno on 14/03/18.
 */

public class TarefaAdapter {
}
