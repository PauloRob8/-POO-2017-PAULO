package ifpi.edu.br.controledetarefas;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

import ifpi.edu.br.controledetarefas.ListaTarefaActivity;
import io.objectbox.Box;

public class MainActivity extends AppCompatActivity {

    EditText chave;
    Box<Usuario> usuarioBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chave = findViewById(R.id.chave);

        usuarioBox = ((App) getApplication()).getBoxStore().boxFor(Usuario.class);
    }


    public void confirmar(View view) {
        String key = chave.getText().toString();
        List<Usuario> result = usuarioBox.query()
                .equal(Usuario_.chave, key).build().find();

        if (!chave.getText().toString().trim().isEmpty())
            if (result.size() > 0) {
                Toast.makeText(this,"Bem Vindo",Toast.LENGTH_LONG ).show();
                carregaUsuario(result.get(0));
            } else {
                Toast.makeText(this, "Chave incorreta,Digite novamente", Toast.LENGTH_LONG).show();
            }
        else
            Toast.makeText(this,"Chave não preenchida",Toast.LENGTH_LONG).show();
    }

    private void carregaUsuario(Usuario usuario) {
        SharedPreferences preferences = getSharedPreferences("controleDeTarefas", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();

        editor.putLong("usuarioId", usuario.getId());

        editor.apply();

        startActivity(new Intent(this, ListaTarefaActivity.class));
        finish();
    }


}
