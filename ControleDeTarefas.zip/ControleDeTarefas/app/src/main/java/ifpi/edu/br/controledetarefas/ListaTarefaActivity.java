package ifpi.edu.br.controledetarefas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import ifpi.edu.br.controledetarefas.TarefaFormularioActivity;

public class ListaTarefaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_tarefa);
    }

    public void AdicionarLivro(View view) {
        startActivity(new Intent(this,TarefaFormularioActivity.class));
    }
}
